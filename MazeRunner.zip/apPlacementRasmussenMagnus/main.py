"""
Author: Magnus Rasmussen
"PressStart2P-Regular.ttf" is from Google Fonts
Project Started: September 21, 2023.
Project Completed: September 25, 2023.
Description: A game where you try to solve mazes from a third-person perspective.
"""

import pygame
import time

# Pygame initiation
pygame.init()
window = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Maze")
pygame.key.set_repeat(1)
running = True

# Colors
black = (0, 0, 0)
blue = (0, 0, 255)
dark_gray = (60, 60, 60)
gray = (128, 128, 128)
green = (255, 0, 0)
peach = (255, 218, 185)
red = (255, 0, 0)
white = (255, 255, 255)
yellow = (255, 255, 0)

# Variable that determines what level or GUI screen the game is currently in
screen = 0

# Variable that turns on for one frame after the mouse is clicked.
mouse_up = False


# The function for displaying text to the screen
def display_text(text, x, y, size=35):
    pixel_font = pygame.font.Font("PressStart2P-Regular.ttf", size)
    rendered_text = pixel_font.render(text, False, black)
    text_rect = rendered_text.get_rect(center=(x, y))
    window.blit(rendered_text, text_rect)


# Class for the walls of the levels
class Wall:
    def __init__(self, x, y, w, h):
        self.x = x
        self.original_x = x
        self.y = y
        self.original_y = y
        self.w = w
        self.original_w = w
        self.h = h
        self.original_h = h

    # Displays the wall to the screen
    def run(self):
        pygame.draw.rect(window, dark_gray, (self.x, self.y, self.w, self.h))

    # Resets the position of the wall
    def reset(self):
        self.x = self.original_x
        self.y = self.original_y
        self.w = self.original_w
        self.h = self.original_h


# Class the goal zones of the levels
class GoalZone:
    def __init__(self, x, y, w, h):
        self.x = x
        self.original_x = x
        self.y = y
        self.original_y = y
        self.w = w
        self.original_w = w
        self.h = h
        self.original_h = h

    # Displays the goal zone to the screen
    def run(self):
        pygame.draw.rect(window, yellow, (self.x, self.y, self.w, self.h))

        # Ends level and goes to the victory screen if the player is inside the goal zone
        if self.x <= 400 <= self.x + self.w and self.y <= 300 <= self.y + self.h:
            global screen
            screen = 7

    # Resets the goal zone to its original position
    def reset(self):
        self.x = self.original_x
        self.y = self.original_y
        self.w = self.original_w
        self.h = self.original_h


# List of every object on screen
objects = []


# Class for all levels in the game (each level is basically a collection of walls and a goal zone)
class Level:
    def __init__(self, num, goal_zone, *level_walls):
        self.screen_num = num + 2
        self.goal_zone = goal_zone
        self.level_walls = level_walls
        # Records the elapsed time by comparing the seconds since 2000 when the level started and when in-game
        self.start_time = time.time()

    # Function that displays the level to the screen
    # This function acts very similarly to the GUI functions
    # in that it is run if global variable screen is equal to level.screen_num
    def run(self):
        window.fill(gray)

        # Displays the walls to the screen
        for level_wall in self.level_walls:
            level_wall.run()

        # Displays the goal zone to the screen
        self.goal_zone.run()

        # Displays the elapsed time in the maze to the screen
        time_elapsed = round(time.time() - self.start_time)
        display_text(str(f"Time:{time_elapsed}"), 200, 75, 30)

        # Displays the square to the screen
        pygame.draw.rect(window, red, (390, 290, 20, 20))

    # Resets the level
    def reset(self):
        for wall in self.level_walls:
            wall.reset()

        self.goal_zone.reset()
        self.start_time = time.time()


# Class for all the buttons in the GUIs
class Button:
    def __init__(self, x, y, w, h, text, color1, color2, num, level_to_reset=None):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.text = text
        self.color1 = color1
        self.color2 = color2
        self.num = num
        self.level_to_reset = level_to_reset

    # Function that displays the button to the screen and checks if it is clicked
    def run(self):
        # The actual pygame.draw functions that display the button to the screen
        pygame.draw.rect(window, self.color2, (self.x, self.y + 10, self.w, self.h - 20))
        pygame.draw.rect(window, self.color2, (self.x + 10, self.y, self.w - 20, 10))
        pygame.draw.rect(window, self.color2, (self.x + 10, self.y + self.h - 10, self.w - 20, 10))
        pygame.draw.rect(window, self.color1, (self.x + 10, self.y + 10, self.w - 20, self.h - 20))
        display_text(self.text, self.x + self.w / 2, self.y + self.h / 2)

        # Changes screen_number and thus the GUI screen when the button is clicked on
        # If the button has a level_to_reset value, then the reset() method for that object is called
        global mouse_up
        global screen
        if mouse_up and self.x <= pygame.mouse.get_pos()[0] <= self.x + self.w and \
                self.y <= pygame.mouse.get_pos()[1] <= self.y + self.h:
            if self.level_to_reset is not None:
                self.level_to_reset.reset()

            screen = self.num


# All the levels of the game
level1 = Level(1, GoalZone(2200, 500, 200, 200), Wall(200, 100, 100, 400), Wall(0, 500, 400, 100),
               Wall(-100, 400, 200, 100), Wall(0, 100, 100, 300), Wall(500, 100, 100, 500), Wall(600, 100, 500, 100),
               Wall(0, 700, 600, 100), Wall(700, 300, 100, 300), Wall(800, 300, 300, 100), Wall(1100, 300, 100, 600),
               Wall(-300, 400, 100, 100), Wall(-200, 600, 100, 300), Wall(-300, 900, 1500, 100),
               Wall(-200, -200, 100, 500), Wall(-300, -100, 100, 100), Wall(-400, -400, 100, 1600),
               Wall(-300, -400, 3500, 100), Wall(0, -300, 100, 300), Wall(400, -100, 800, 100),
               Wall(500, -200, 100, 100), Wall(700, -300, 100, 100), Wall(900, -200, 100, 100),
               Wall(1100, -300, 100, 200), Wall(-300, 1100, 3500, 100), Wall(1300, 900, 400, 100),
               Wall(1300, 0, 100, 600), Wall(1500, -300, 100, 1200), Wall(1600, -100, 100, 300),
               Wall(1800, -200, 100, 500), Wall(1900, -200, 900, 100), Wall(2100, 0, 100, 200),
               Wall(1700, 300, 100, 500), Wall(1800, 300, 400, 100), Wall(1900, 500, 100, 400),
               Wall(2000, 700, 500, 100), Wall(2100, 400, 100, 300), Wall(1800, 900, 700, 100),
               Wall(2200, 1000, 100, 100), Wall(2400, 200, 100, 500), Wall(2400, 0, 700, 100),
               Wall(2600, 200, 100, 900), Wall(2800, 200, 100, 400), Wall(2900, 500, 100, 300),
               Wall(2800, 700, 100, 300), Wall(2900, 900, 200, 100), Wall(2900, -200, 200, 100),
               Wall(3100, -300, 100, 1400))

level2 = Level(2, GoalZone(700, 200, 200, 200), Wall(500, -300, 600, 200), Wall(500, -100, 200, 500),
               Wall(100, 100, 400, 100), Wall(600, 100, 700, 100), Wall(300, 400, 1500, 100), Wall(100, 400, 200, 500),
               Wall(-200, 800, 300, 100), Wall(-200, 0, 200, 700), Wall(-400, 0, 100, 1000), Wall(-400, -100, 800, 100),
               Wall(300, -400, 100, 300), Wall(300, -500, 1000, 100), Wall(-400, 1000, 1500, 100),
               Wall(400, 800, 600, 100), Wall(400, 600, 100, 100), Wall(600, 600, 100, 100), Wall(800, 600, 100, 100),
               Wall(1000, 600, 100, 400), Wall(1200, 500, 200, 500), Wall(1200, 1100, 200, 100),
               Wall(1500, 800, 100, 400), Wall(1400, 600, 300, 100), Wall(1800, 400, 100, 700),
               Wall(1900, 600, 500, 100), Wall(2100, 200, 100, 400), Wall(2300, -600, 100, 1200),
               Wall(2500, -600, 100, 1800), Wall(2100, -400, 100, 500), Wall(2000, 800, 500, 100),
               Wall(1900, 1000, 500, 100), Wall(1400, -500, 800, 100), Wall(1400, -400, 100, 400),
               Wall(1500, -200, 400, 100), Wall(1300, -100, 100, 100), Wall(1200, -400, 100, 500),
               Wall(1400, 100, 500, 100), Wall(1400, 200, 100, 200), Wall(-600, 200, 100, 600),
               Wall(-500, 700, 100, 100), Wall(-1100, 400, 500, 200), Wall(-1200, 200, 100, 600),
               Wall(-1000, 200, 100, 100), Wall(-1200, 900, 100, 300), Wall(-1000, 600, 100, 400),
               Wall(-1000, 1100, 100, 100), Wall(-800, 700, 100, 500), Wall(-600, 900, 100, 300),
               Wall(-1400, 1200, 4000, 100), Wall(-1400, -600, 100, 1800), Wall(-1400, -700, 4000, 100),
               Wall(-1300, -300, 100, 200), Wall(-1300, 0, 400, 100), Wall(-800, 0, 100, 300), Wall(-700, 0, 200, 100),
               Wall(-600, -100, 100, 100), Wall(-1100, -300, 1300, 100),  Wall(-1100, -200, 600, 100),
               Wall(-1100, -400, 100, 100), Wall(-1200, -500, 1400, 100), Wall(100, -600, 100, 100))

level3 = Level(3, GoalZone(300, -5800, 200, 200), Wall(200, -5900, 100, 6100), Wall(300, -5900, 200, 100),
               Wall(500, -5900, 100, 6100), Wall(-5800, 100, 6000, 100), Wall(-5800, 200, 100, 200),
               Wall(-5800, 400, 6000, 100), Wall(200, 400, 100, 6100), Wall(300, 6400, 200, 100),
               Wall(500, 400, 100, 6100), Wall(600, 400, 6000, 100), Wall(6500, 200, 100, 200),
               Wall(600, 100, 6000, 100))

level4 = Level(4, GoalZone(2900, 0, 200, 600), Wall(300, 400, 300, 100), Wall(300, 100, 300, 100),
               Wall(700, 100, 100, 500), Wall(900, 300, 400, 100), Wall(900, 400, 100, 300), Wall(400, 600, 500, 100),
               Wall(300, -100, 700, 100), Wall(900, -100, 100, 300), Wall(300, -100, 600, 100),
               Wall(1100, -200, 100, 400), Wall(1200, -100, 100, 100), Wall(1100, 500, 100, 300),
               Wall(1300, -100, 100, 600), Wall(1300, 600, 200, 100), Wall(1500, -100, 100, 800),
               Wall(1600, -100, 1600, 100), Wall(1800, 600, 1400, 100), Wall(3100, 0, 100, 600),
               Wall(200, -200, 100, 1000), Wall(200, -300, 1600, 100), Wall(1700, -200, 100, 100),
               Wall(200, 800, 1600, 100), Wall(1700, 600, 100, 200), Wall(1700, 100, 300, 100),
               Wall(1800, 200, 100, 200), Wall(2100, 100, 100, 300), Wall(2200, 200, 100, 100),
               Wall(2300, 100, 100, 300), Wall(2500, 100, 100, 100), Wall(2500, 300, 100, 100),
               Wall(2600, 200, 100, 100), Wall(2700, 100, 100, 100), Wall(2700, 300, 100, 100))

# A list of all the levels
levels = [level1, level2, level3, level4]


# Function for the starting screen of the game
def start():
    window.fill(peach)

    display_text("Maze", 400, 100, 50)
    Button(225, 200, 350, 100, "Play", red, gray, 2).run()
    Button(225, 400, 350, 100, "Controls", blue, gray, 1).run()


# Function for the control screen
def controls():
    window.fill(peach)

    display_text("UP: Move up", 400, 100)
    display_text("DOWN: Move down", 400, 200)
    display_text("LEFT: Move left", 400, 300)
    display_text("RIGHT: Move right", 400, 400)
    display_text("Esc: Return to home", 400, 500)


# Function for the level select screen
def level_select():
    window.fill(peach)

    Button(50, 100, 300, 100, "Level 1", white, red, 3, level_to_reset=level1).run()
    Button(450, 100, 300, 100, "Level 2", white, blue, 4, level_to_reset=level2).run()
    Button(50, 400, 300, 100, "Level 3", white, yellow, 5, level_to_reset=level3).run()
    Button(450, 400, 300, 100, "Level 4", white, green, 6, level_to_reset=level4).run()


# Function for the victory screen
def victory():
    window.fill(gray)

    display_text("You won!", 400, 225)
    display_text("Click to return home.", 400, 375)

    if mouse_up:
        global screen
        screen = 0


# Pygame loop
while running:
    # Resets mouse_up after it is true for one frame
    mouse_up = False

    # Event loop
    for event in pygame.event.get():
        # Quits pygame without an error if the window is closed
        if event.type == pygame.QUIT:
            running = False

        # All pygame key events
        if event.type == pygame.KEYDOWN:
            # Returns to home screen when the escape button is pressed
            if event.key == pygame.K_ESCAPE:
                screen = 0

            # Wall collision detection and player movement
            # (the map moves around the player box instead of the other way around)
            # This works by first using a for loop to check if the player can move in a certain direction,
            # and then using another for loop to actually move the player
            if event.key == pygame.K_RIGHT:
                collided_right = False

                for obj in objects:
                    if isinstance(obj, Wall) and obj.x == 410 and \
                            (obj.y < 290 < obj.y + obj.h or obj.y < 310 < obj.y + obj.h):
                        collided_right = True

                for obj in objects:
                    if not collided_right:
                        obj.x -= 1

            if event.key == pygame.K_LEFT:
                collided_left = False

                for obj in objects:
                    if isinstance(obj, Wall) and obj.x + obj.w == 390 and \
                            (obj.y < 290 < obj.y + obj.h or obj.y < 310 < obj.y + obj.h):
                        collided_left = True

                for obj in objects:
                    if not collided_left:
                        obj.x += 1

            if event.key == pygame.K_DOWN:
                collided_down = False

                for obj in objects:
                    if isinstance(obj, Wall) and obj.y == 310 and \
                            (obj.x < 390 < obj.x + obj.w or obj.x < 410 < obj.x + obj.w):
                        collided_down = True

                for obj in objects:
                    if not collided_down:
                        obj.y -= 1

            if event.key == pygame.K_UP:
                collided_up = False

                for obj in objects:
                    if isinstance(obj, Wall) and obj.y + obj.h == 290 and \
                            (obj.x < 390 < obj.x + obj.w or obj.x < 410 < obj.x + obj.w):
                        collided_up = True

                for obj in objects:
                    if not collided_up:
                        obj.y += 1

        # Sets global boolean mouse_up to true for one frame after the mouse button is released
        # Better version of pygame.mouse.get_pressed()
        elif event.type == pygame.MOUSEBUTTONUP:
            mouse_up = True

    # Runs a certain GUI screen function depending on the value of the variable screen
    # If screen is equal to 3, 4, 5, or 6, then a level will be displayed to the window instead of a GUI screen
    # When a level is displayed to the screen, its run() method is called and objects is redefined to contain
    # only that level's walls and goal zone
    if screen == 0:
        start()
    elif screen == 1:
        controls()
    elif screen == 2:
        level_select()
    elif screen == 3:
        while len(objects) > 0:
            objects.pop(-1)

        for lw in level1.level_walls:
            objects.append(lw)

        objects.append(level1.goal_zone)

        level1.run()
    elif screen == 4:
        while len(objects) > 0:
            objects.pop(-1)

        for lw in level2.level_walls:
            objects.append(lw)

        objects.append(level2.goal_zone)

        level2.run()
    elif screen == 5:
        while len(objects) > 0:
            objects.pop(-1)

        for lw in level3.level_walls:
            objects.append(lw)

        objects.append(level3.goal_zone)

        level3.run()
    elif screen == 6:
        while len(objects) > 0:
            objects.pop(-1)

        for lw in level4.level_walls:
            objects.append(lw)

        objects.append(level4.goal_zone)

        level4.run()
    elif screen == 7:
        victory()

    pygame.display.update()

pygame.quit()
quit()
